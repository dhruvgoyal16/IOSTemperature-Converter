//
//  ConvertedTests.swift
//  ConvertedTests
//
//  Created by Dhruv Goyal on 10/03/25.
//

import Testing
@testable import Converted

struct ConvertedTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
