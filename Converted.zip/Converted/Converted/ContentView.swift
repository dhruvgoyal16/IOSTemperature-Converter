import SwiftUI

struct ContentView: View {
    @FocusState private var valueIsFocused: Bool
    @State private var tempValue = 0.0
    @State private var tempUnit = "Celsius"
    @State private var selectedUnit = "Fahrenheit"
    @State private var tempUnits = ["Celsius", "Fahrenheit", "Kelvin"]
    
    var calculatedTemperature: Double {
        switch (tempUnit, selectedUnit) {
        case ("Celsius", "Fahrenheit"):
            return (tempValue * 9/5) + 32
        case ("Celsius", "Kelvin"):
            return tempValue + 273.15
        case ("Fahrenheit", "Celsius"):
            return (tempValue - 32) * 5/9
        case ("Fahrenheit", "Kelvin"):
            return (tempValue - 32) * 5/9 + 273.15
        case ("Kelvin", "Celsius"):
            return tempValue - 273.15
        case ("Kelvin", "Fahrenheit"):
            return (tempValue - 273.15) * 9/5 + 32
        default:
            return tempValue
        }
    }
    
    var body: some View {
        NavigationStack {
            Text("Temprature")
            Form {
                Section("Step-1: Enter the Conversion Value") {
                    TextField("Enter the value", value: $tempValue, format: .number)
                        .keyboardType(.decimalPad)
                        .focused($valueIsFocused)
                    
                    Picker("Select Input Unit", selection: $tempUnit) {
                        ForEach(tempUnits, id: \.self) {
                            Text($0)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                
                Section("Step-2: Select the Unit to Convert To") {
                    Picker("Select Output Unit", selection: $selectedUnit) {
                        ForEach(tempUnits, id: \.self) {
                            Text($0)
                        }
                    }
                    .pickerStyle(.segmented)
                    
                    Text("Output: \(calculatedTemperature) \(selectedUnit)")
                }
            }
            .navigationTitle("Convert in Just 2 Steps")
           
        }
    }
}

#Preview {
    ContentView()
}
