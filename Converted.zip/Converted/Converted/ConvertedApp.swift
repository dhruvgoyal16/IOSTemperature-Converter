//
//  ConvertedApp.swift
//  Converted
//
//  Created by Dhruv Goyal on 10/03/25.
//

import SwiftUI

@main
struct ConvertedApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
